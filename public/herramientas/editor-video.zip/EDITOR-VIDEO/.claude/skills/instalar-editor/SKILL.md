---
name: instalar-editor
description: Instala y deja listo todo lo necesario para editar videos con Claude (Node.js, ffmpeg, Remotion). Úsala cuando la persona diga "instala el editor", "prepara todo para editar", "configura el editor", "no me funciona" o abra esta carpeta por primera vez.
---

# Instalar el editor

Objetivo: dejar listas las herramientas para editar video desde el chat: Node.js, ffmpeg y Remotion. **No hay interfaz ni plantillas**: Claude edita escribiendo código de Remotion y usando ffmpeg. Hablas en **español, simple y corto**; la persona no programa. Explica cada paso en una frase antes de correrlo y pide confirmación antes de instalar programas. Si algo falla, di qué pasó en simple y arréglalo.

La carpeta raíz es la que contiene `.claude/` y `proyecto/` (el proyecto de Remotion está en `proyecto/mi-video`).

## 1. Ver qué falta

```
node .claude/skills/instalar-editor/comprobar.mjs
```

Si `node` no existe, ve al paso 2. El script no instala nada: marca [ok] o [FALTA]. Instala **solo lo que falte**.

## 2. Programas (una sola vez)

**Windows** (PowerShell):
- Node.js 24: `winget install OpenJS.NodeJS.LTS`
- ffmpeg: `winget install Gyan.FFmpeg`
- Después **cierra y vuelve a abrir** la app de Claude para que reconozca los programas.

**Mac** (Terminal):
- Homebrew si no está: `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"` (pide la contraseña de la Mac; al final corre las 2 líneas de "Next steps").
- `brew install node@24 ffmpeg`

Alternativa sin winget/brew: Node desde nodejs.org y ffmpeg desde ffmpeg.org.

## 3. Motor (Remotion)

```
npm install --prefix proyecto/mi-video
```

Tarda unos minutos. Es lo que dibuja los gráficos y exporta el video.

## 4. Carpetas de trabajo

Asegúrate de que existan estas tres carpetas en la raíz (si falta alguna, créala):

```
node -e "for (const d of ['originales','recursos','entregas']) require('fs').mkdirSync(d,{recursive:true})"
```

- `originales/`: aquí la persona deja sus videos crudos (nunca se modifican).
- `recursos/`: logos, capturas y grabaciones de pantalla, una subcarpeta por video.
- `entregas/`: aquí salen los MP4 finales.

## 5. Verificar

1. Corre `comprobar.mjs` otra vez: debe decir "Todo listo para editar".
2. Prueba Remotion: `npx remotion compositions` dentro de `proyecto/mi-video` debe listar composiciones sin errores.
3. Avísale que la **primera vez** que edite un video se descarga el modelo de voz (Whisper, ~1,6 GB, solo si usa `scripts/transcribe.mts`): tarda un rato y es una sola vez.

## 6. Empezar

Dile: "Listo. Deja tu video en la carpeta originales y dime cómo lo quieres editar." Las reglas de edición están en `CLAUDE.md`.

## Problemas comunes

- **`npm`/`node`/`ffmpeg` no se reconoce** → falta cerrar y reabrir la app de Claude tras instalar.
- **Sin tarjeta NVIDIA** → funciona igual: el codificador cae solo a libx264 (`scripts/codec.mjs`), un poco más lento.
- **El disco se llena** → Remotion deja carpetas `remotion-webpack-bundle-*` en la carpeta temporal del sistema; se pueden borrar.
- **La PC se calienta al exportar** → usar pocos núcleos: `npx remotion render <Id> entregas/video.mp4 --concurrency=2`.

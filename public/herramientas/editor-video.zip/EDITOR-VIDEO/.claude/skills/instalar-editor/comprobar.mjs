// Revisa si la PC tiene todo para editar con el Studio. No instala nada: solo dice qué falta.
// Uso: node .claude/skills/instalar-editor/comprobar.mjs   (desde la carpeta raíz del editor)
import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { join, resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const raiz = resolve(dirname(fileURLToPath(import.meta.url)), "../../..");
const motor = join(raiz, "proyecto", "mi-video");
const sh = (cmd, args) => { const r = spawnSync(cmd, args, { encoding: "utf8", shell: process.platform === "win32" }); return r.status === 0 ? (r.stdout || r.stderr).trim() : null; };
import { mkdirSync } from "node:fs";
for (const c of ["originales", "recursos", "entregas"]) mkdirSync(join(raiz, c), { recursive: true }); // las tres carpetas de trabajo
const filas = [];
const fila = (nombre, ok, detalle, arreglo) => filas.push({ nombre, ok, detalle, arreglo });

const [mayor, menor] = process.versions.node.split(".").map(Number);
const nodeOk = mayor >= 24 || (mayor === 22 && menor >= 13) || (mayor === 20 && menor >= 19);
fila("Node.js", nodeOk, `v${process.versions.node}`, "instalar Node 24 (LTS)");

const ff = sh("ffmpeg", ["-version"]);
fila("ffmpeg", !!ff, ff ? ff.split("\n")[0].slice(0, 40) : "no está", "instalar ffmpeg");
const fp = sh("ffprobe", ["-version"]);
fila("ffprobe", !!fp, fp ? "ok" : "no está", "viene con ffmpeg");

fila("Motor (carpeta)", existsSync(join(motor, "package.json")), motor, "descomprimir el zip completo");
fila("Dependencias (npm install)", existsSync(join(motor, "node_modules", "remotion")), "node_modules", "npm install en proyecto/mi-video");
fila("Carpetas originales/recursos/entregas", ["originales", "recursos", "entregas"].every((c) => existsSync(join(raiz, c))), "creadas", "crearlas en la raíz");

if (ff) {
  const nv = spawnSync("ffmpeg", ["-v", "error", "-f", "lavfi", "-i", "color=s=256x256:d=0.2", "-c:v", "h264_nvenc", "-f", "null", "-"], { encoding: "utf8" }).status === 0;
  filas.push({ nombre: "Codificador", ok: true, detalle: nv ? "tarjeta NVIDIA (rápido)" : "procesador (libx264, un poco más lento)", arreglo: "" });
}

console.log(`\nRevisión del editor en ${process.platform}\n`);
for (const f of filas) console.log(`${f.ok ? "[ok]   " : "[FALTA]"} ${f.nombre.padEnd(28)} ${f.detalle}${f.ok ? "" : "  ->  " + f.arreglo}`);
const faltan = filas.filter((f) => !f.ok);
console.log(faltan.length ? `\nFaltan ${faltan.length} cosa(s).` : "\nTodo listo para editar.");
process.exit(faltan.length ? 1 : 0);

import { Composition } from "remotion";
import { HelloWorld } from "./HelloWorld";

// Cada <Composition> es un video que se puede ver y exportar. Claude agrega aquí las composiciones nuevas.
export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="HelloWorld"
        component={HelloWorld}
        durationInFrames={150}
        fps={30}
        width={1080}
        height={1920}
        defaultProps={{
          titleText: "Welcome to Remotion",
          titleColor: "#000000",
        }}
      />
    </>
  );
};

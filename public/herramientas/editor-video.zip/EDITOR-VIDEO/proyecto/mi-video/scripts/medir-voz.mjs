// Muestra el volumen de la voz cada 20 ms entre dos segundos, para cortar EXACTO donde empieza o termina una palabra
// (Whisper estira la última palabra de cada frase; esto no).
//
// Uso: node scripts/medir-voz.mjs <audio.wav> <desde> <hasta>
//   → "189.26:-30 189.28:-40 189.30:-52 …"  (la palabra terminó cuando baja de ~−40 dB y no vuelve a subir)
import { spawnSync } from "node:child_process";

const [audio, desde, hasta] = process.argv.slice(2);
if (!audio || desde === undefined || hasta === undefined) throw new Error("Uso: medir-voz.mjs <audio.wav> <desde> <hasta>");
const SR = 16000;
const r = spawnSync("ffmpeg", ["-v", "error", "-ss", desde, "-to", hasta, "-i", audio, "-ac", "1", "-ar", String(SR), "-f", "s16le", "-"], { maxBuffer: 1 << 28 });
if (r.status !== 0) throw new Error(r.stderr.toString());
const muestras = new Int16Array(r.stdout.buffer, r.stdout.byteOffset, Math.floor(r.stdout.length / 2));
const paso = SR * 0.02;
const salida = [];
for (let i = 0; i + paso <= muestras.length; i += paso) {
  let suma = 0;
  for (let k = i; k < i + paso; k++) suma += muestras[k] * muestras[k];
  const rms = Math.sqrt(suma / paso) / 32768;
  const db = rms > 0 ? 20 * Math.log10(rms) : -120;
  salida.push(`${(Number(desde) + i / SR).toFixed(2)}:${Math.max(-99, Math.round(db))}`);
}
console.log(salida.join(" "));

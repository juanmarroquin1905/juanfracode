// Saca fotos (PNG) de varios fotogramas de una composición, empaquetando el proyecto una sola vez.
// Uso: node scripts/fotos.mjs <ID> <carpeta-salida> <frame1> <frame2> ...
// Ejemplo: node scripts/fotos.mjs VIDEO-4 ../../entregas/fotos 0 150 300
import { bundle } from "@remotion/bundler";
import { renderStill, selectComposition } from "@remotion/renderer";
import { mkdirSync, rmSync } from "node:fs";
import path from "node:path";

const [id, out, ...frames] = process.argv.slice(2);
if (!id || !out || frames.length === 0) throw new Error("Uso: node scripts/fotos.mjs <ID> <carpeta> <frames...>");
mkdirSync(out, { recursive: true });
const serveUrl = await bundle({ entryPoint: path.resolve("src/index.ts") });
const composition = await selectComposition({ serveUrl, id });
for (const fr of frames.map(Number)) {
  const output = path.join(out, `${id}_${String(fr).padStart(5, "0")}.png`);
  await renderStill({ serveUrl, composition, frame: fr, output, scale: 0.5 });
  console.log("ok", output);
}
// Remotion deja una copia de public/ (más de 2 GB) en los temporales cada vez: la borramos al terminar
rmSync(serveUrl, { recursive: true, force: true });

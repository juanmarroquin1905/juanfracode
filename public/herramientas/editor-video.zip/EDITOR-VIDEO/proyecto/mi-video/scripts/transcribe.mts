// Transcribe un video localmente (Whisper en la GPU) y guarda los subtítulos palabra por palabra.
// Uso: npx tsx scripts/transcribe.mts public/IMG_8890.mp4 transcripts/IMG_8890.json [modelo] [idioma]
import { registerMediabunnyServer } from "@mediabunny/server";
import {
  WHISPER_WEBGPU_SAMPLE_RATE,
  canUseWhisperWebGpu,
  downloadWhisperModel,
  getAvailableModels,
  loadWhisperModel,
  toCaptions,
  transcribe,
} from "@remotion/whisper-webgpu";
import {
  ALL_FORMATS,
  Conversion,
  FilePathSource,
  Input,
  NullTarget,
  Output,
  WavOutputFormat,
} from "mediabunny";
import { mkdir, writeFile } from "node:fs/promises";
import { dirname } from "node:path";

const [src, out, model = "small", language = "es"] = process.argv.slice(2);
if (!src || !out) throw new Error("Uso: transcribe.mts <video> <salida.json> [modelo] [idioma]");

registerMediabunnyServer();

const support = await canUseWhisperWebGpu();
if (!support.supported) throw new Error(support.detailedReason);
console.log("Modelos disponibles:", getAvailableModels().map((m) => (typeof m === "string" ? m : JSON.stringify(m))).join(", "));

type WaveformChunk = { startFrame: number; waveform: Float32Array };
const chunks: WaveformChunk[] = [];

using input = new Input({ formats: ALL_FORMATS, source: new FilePathSource(src) });
const audioTrack = await input.getPrimaryAudioTrack();
if (audioTrack === null) throw new Error("El video no tiene audio.");

const conversion = await Conversion.init({
  input,
  output: new Output({ format: new WavOutputFormat(), target: new NullTarget() }),
  video: { discard: true },
  audio: (track) => {
    if (track.id !== audioTrack.id) return { discard: true };
    return {
      codec: "pcm-f32",
      forceTranscode: true,
      numberOfChannels: 1,
      sampleFormat: "f32",
      sampleRate: WHISPER_WEBGPU_SAMPLE_RATE,
      process: (sample) => {
        const waveform = new Float32Array(
          sample.allocationSize({ format: "f32", planeIndex: 0 }) / Float32Array.BYTES_PER_ELEMENT,
        );
        sample.copyTo(waveform, { format: "f32", planeIndex: 0 });
        chunks.push({ startFrame: Math.round(sample.timestamp * WHISPER_WEBGPU_SAMPLE_RATE), waveform });
        return sample;
      },
    };
  },
});
if (!conversion.isValid) throw new Error("No se pudo decodificar el audio.");
await conversion.execute();

const len = chunks.reduce((m, c) => Math.max(m, c.startFrame + c.waveform.length), 0);
const channelWaveform = new Float32Array(len);
for (const c of chunks) {
  const d = Math.max(0, c.startFrame);
  const s = Math.max(0, -c.startFrame);
  const n = Math.min(c.waveform.length - s, channelWaveform.length - d);
  if (n > 0) channelWaveform.set(c.waveform.subarray(s, s + n), d);
}

console.log(`Modelo: ${model}, idioma: ${language}`);
await downloadWhisperModel({ model: model as never });
await using modelHandle = await loadWhisperModel({ model: model as never });
void modelHandle; // se mantiene cargado hasta el final del script
const transcription = await transcribe({ channelWaveform, model: model as never, language } as never);
const { captions } = toCaptions({ whisperWebGpuOutput: transcription });

await mkdir(dirname(out), { recursive: true });
await writeFile(out, JSON.stringify(captions, null, 2));
console.log(`Listo: ${captions.length} palabras -> ${out}`);

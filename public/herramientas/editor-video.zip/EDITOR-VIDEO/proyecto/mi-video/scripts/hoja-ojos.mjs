// Hoja con la cara al INICIO y al FINAL de cada toma, para ver si miro a cámara (o al costado leyendo el guion).
//
// Uso: node scripts/hoja-ojos.mjs <video> <salida.jpg> <desde:hasta> [<desde:hasta> …] [--cara=330,620,420,300]
//   --cara = x,y,ancho,alto del recorte de la cara en el video (1080×1920). Mídelo una vez con una foto.
import { spawnSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";

const args = process.argv.slice(2);
const flags = args.filter((a) => a.startsWith("--"));
const [video, salida, ...tomas] = args.filter((a) => !a.startsWith("--"));
if (!video || !salida || tomas.length === 0) throw new Error("Uso: hoja-ojos.mjs <video> <salida.jpg> desde:hasta …");
const [cx, cy, cw, ch] = (flags.find((f) => f.startsWith("--cara="))?.split("=")[1] ?? "330,620,420,300").split(",").map(Number);
const dir = mkdtempSync(path.join(tmpdir(), "ojos-"));
try {
  let n = 0;
  for (const t of tomas) {
    const [a, b] = t.split(":").map(Number);
    for (const s of [a + 0.02, b - 0.03]) {
      n++;
      spawnSync("ffmpeg", ["-v", "error", "-y", "-ss", String(s), "-i", video, "-frames:v", "1", "-vf", `crop=${cw}:${ch}:${cx}:${cy},scale=240:-1`, path.join(dir, `${String(n).padStart(3, "0")}.jpg`)]);
    }
  }
  const r = spawnSync("ffmpeg", ["-v", "error", "-y", "-framerate", "1", "-i", path.join(dir, "%03d.jpg"), "-vf", `tile=8x${Math.ceil(n / 8)}`, "-frames:v", "1", salida]);
  if (r.status !== 0) throw new Error(r.stderr.toString());
  console.log(`ok ${salida}: ${n} caras (izquierda = inicio de la toma, derecha = final)`);
} finally {
  rmSync(dir, { recursive: true, force: true });
}

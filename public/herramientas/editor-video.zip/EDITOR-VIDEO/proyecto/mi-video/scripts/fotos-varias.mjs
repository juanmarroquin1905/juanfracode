// Saca una foto de varias composiciones empaquetando el proyecto una sola vez.
// Uso: node scripts/fotos-varias.mjs <carpeta> <ID:frame> <ID:frame> ...
// Ejemplo: node scripts/fotos-varias.mjs ../../entregas/fotos HelloWorld:30 OtraComposicion:90
import { bundle } from "@remotion/bundler";
import { renderStill, selectComposition } from "@remotion/renderer";
import { mkdirSync, rmSync } from "node:fs";
import path from "node:path";

const [out, ...pedidos] = process.argv.slice(2);
if (!out || !pedidos.length) throw new Error("Uso: node scripts/fotos-varias.mjs <carpeta> <ID:frame>...");
mkdirSync(out, { recursive: true });
const serveUrl = await bundle({ entryPoint: path.resolve("src/index.ts") });
for (const p of pedidos) {
  const [id, fr] = p.split(":");
  const composition = await selectComposition({ serveUrl, id });
  const output = path.join(out, `${id}_${fr}.png`);
  await renderStill({ serveUrl, composition, frame: Number(fr), output, scale: 0.4 });
  console.log("ok", output);
}
// Remotion deja una copia de public/ (más de 2 GB) en los temporales cada vez: la borramos al terminar
rmSync(serveUrl, { recursive: true, force: true });

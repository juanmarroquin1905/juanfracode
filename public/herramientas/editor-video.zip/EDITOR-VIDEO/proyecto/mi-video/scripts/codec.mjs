// Elige el codificador de video según la PC: tarjeta NVIDIA (h264_nvenc) o, si no hay, libx264 (CPU).
// Lo usan preparar.mjs y el servidor del Studio, así funciona igual en Windows, Mac y Linux.
import { spawnSync } from "node:child_process";

const probar = (codec) =>
  spawnSync("ffmpeg", ["-v", "error", "-f", "lavfi", "-i", "color=s=256x256:d=0.2", "-c:v", codec, "-f", "null", "-"], { encoding: "utf8" }).status === 0;

export const HAY_NVENC = probar("h264_nvenc");

// nv = argumentos para la tarjeta NVIDIA, cpu = argumentos para libx264
export const videoArgs = (nv, cpu) => ["-c:v", ...(HAY_NVENC ? ["h264_nvenc", ...nv] : ["libx264", ...cpu])];

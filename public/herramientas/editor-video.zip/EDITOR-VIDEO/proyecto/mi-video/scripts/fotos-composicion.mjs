// Fotos de cualquier composición de Remotion en varios segundos, en una hoja (para revisar sin exportar el video).
// Uso: node scripts/fotos-composicion.mjs <IdComposicion> "<carpeta>" 1.5 6 12 ...   [--escala=0.5] [--cols=3]
import { bundle } from "@remotion/bundler";
import { renderStill, selectComposition } from "@remotion/renderer";
import { spawnSync } from "node:child_process";
import { mkdirSync, rmSync } from "node:fs";
import path from "node:path";

const [id, carpeta, ...resto] = process.argv.slice(2);
const flags = resto.filter((x) => x.startsWith("--"));
const segundos = resto.filter((x) => !x.startsWith("--")).map(Number);
const escala = Number((flags.find((x) => x.startsWith("--escala=")) || "--escala=0.5").split("=")[1]);
const cols = Number((flags.find((x) => x.startsWith("--cols=")) || "--cols=3").split("=")[1]);
mkdirSync(carpeta, { recursive: true });
const serveUrl = await bundle({ entryPoint: path.resolve("src/index.ts") });
const fotos = [];
try {
  const composition = await selectComposition({ serveUrl, id });
  for (const s of segundos) {
    const frame = Math.min(composition.durationInFrames - 1, Math.round(s * composition.fps));
    const sal = path.join(carpeta, `${id}_${String(s).replace(".", "_")}.jpg`);
    await renderStill({ serveUrl, composition, frame, output: sal, scale: escala, imageFormat: "jpeg", jpegQuality: 80 });
    fotos.push([s, sal]);
  }
} finally {
  rmSync(serveUrl, { recursive: true, force: true });
}
// hoja con el segundo escrito en cada foto
const hoja = path.join(carpeta, `${id}_hoja.jpg`);
const args = ["-v", "error", "-y"];
fotos.forEach(([, f]) => args.push("-i", f));
// letra para el segundo escrito en cada foto (Windows / Mac / Linux)
const FUENTE = process.platform === "win32" ? "C\\:/Windows/Fonts/arialbd.ttf" : process.platform === "darwin" ? "/System/Library/Fonts/Supplemental/Arial Bold.ttf" : "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf";
const filtros = fotos.map(([s], i) => `[${i}:v]drawtext=fontfile='${FUENTE}':text='${s}s':x=10:y=10:fontsize=28:fontcolor=yellow:box=1:boxcolor=black@0.6[v${i}]`).join(";");
const filas = Math.ceil(fotos.length / cols);
const pos = fotos.map((_, i) => `${i % cols === 0 ? "0" : Array.from({ length: i % cols }, () => "w0").join("+")}_${Math.floor(i / cols) === 0 ? "0" : Array.from({ length: Math.floor(i / cols) }, () => "h0").join("+")}`).join("|");
args.push("-filter_complex", `${filtros};${fotos.map((_, i) => `[v${i}]`).join("")}xstack=inputs=${fotos.length}:layout=${pos}:fill=black[o]`, "-map", "[o]", hoja);
const r = spawnSync("ffmpeg", args, { encoding: "utf8" });
if (r.status !== 0) console.error(r.stderr.slice(0, 500));
console.log("hoja", hoja, `(${fotos.length} fotos, ${filas} filas)`);

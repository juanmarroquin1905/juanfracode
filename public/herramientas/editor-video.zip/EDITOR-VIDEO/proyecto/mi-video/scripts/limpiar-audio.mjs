// Limpia y nivela la voz de un video (gratis, solo con FFmpeg, sin enviar nada a internet).
//
// Uso:
//   node scripts/limpiar-audio.mjs <video-original> <salida.wav> [--fuerza=ninguna|suave|media|fuerte]
//   --fuerza=ninguna → SIN reducción de ruido: solo nivela el volumen a -14 LUFS.
// Ejemplo:
//   node scripts/limpiar-audio.mjs ../../originales/IMG_8890.MOV public/IMG_8890_audio.wav
//
// Pasos:
//   1. Filtro de graves (retumbe de motores/aire) y de agudos extremos (siseo).
//   2. Reducción de ruido de fondo (tráfico, ventiladores, zumbidos) que aprende el ruido sobre la marcha.
//   3. Expansor suave: baja el ruido en las pausas (claxons lejanos, calle) sin cortar la voz.
//   4. Volumen a -14 LUFS con pico máximo de -1.5 dB (recomendado para Instagram/TikTok), sin distorsión.
//
// Prueba con IMG_8890 (ruido en una pausa / voz):
//   sin limpiar: -32.7 dB / -17.0 dB
//   suave:       -37.2 dB / -17.0 dB
//   media:       -44.1 dB / -17.0 dB   ← por defecto
//   fuerte:      -50.0 dB / -17.0 dB   (puede sonar algo "metálica"; escúchala antes de usarla)
// Un claxon que suena MIENTRAS hablas no se puede quitar del todo sin dañar la voz.
// El archivo original NUNCA se modifica.
import { spawnSync } from "node:child_process";

const [src, out, ...flags] = process.argv.slice(2);
if (!src || !out) {
  console.error("Uso: node scripts/limpiar-audio.mjs <video-original> <salida.wav> [--fuerza=suave|media|fuerte]");
  process.exit(1);
}
const fuerza = (flags.find((f) => f.startsWith("--fuerza=")) ?? "--fuerza=media").split("=")[1];
const NIVELES = {
  ninguna: null,
  suave: { nr: 8, gate: 0.004, rango: 0.35 },
  media: { nr: 14, gate: 0.007, rango: 0.2 },
  fuerte: { nr: 22, gate: 0.01, rango: 0.1 },
};
if (!(fuerza in NIVELES)) throw new Error(`Fuerza desconocida: ${fuerza} (usa ninguna, suave, media o fuerte)`);
const n = NIVELES[fuerza];

const limpieza = n
  ? [
      "highpass=f=80",
      "lowpass=f=12000",
      `afftdn=nr=${n.nr}:nf=-50:tn=1`,
      `agate=threshold=${n.gate}:ratio=2:range=${n.rango}:attack=8:release=250:knee=4`,
    ].join(",")
  : "anull"; // sin reducción de ruido

const ffmpeg = (args) => {
  const r = spawnSync("ffmpeg", ["-hide_banner", "-nostats", ...args], { encoding: "utf8" });
  if (r.status !== 0) throw new Error(r.stderr);
  return r.stderr; // ffmpeg escribe sus informes en stderr
};

// Pasada 1: medir el volumen después de limpiar
const log = ffmpeg(["-i", src, "-map", "0:a:0", "-af", `${limpieza},loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json`, "-f", "null", "-"]);
const j = JSON.parse(log.slice(log.lastIndexOf("{"), log.lastIndexOf("}") + 1));
const medido = `measured_I=${j.input_i}:measured_TP=${j.input_tp}:measured_LRA=${j.input_lra}:measured_thresh=${j.input_thresh}:offset=${j.target_offset}`;

// Pasada 2: limpiar y nivelar
ffmpeg(["-y", "-i", src, "-map", "0:a:0", "-vn", "-af", `${limpieza},loudnorm=I=-14:TP=-1.5:LRA=11:${medido}:linear=true,aresample=48000`, "-c:a", "pcm_s16le", out]);
console.log(`Listo (${fuerza}): ${out} · volumen ${j.input_i} LUFS → -14 LUFS`);

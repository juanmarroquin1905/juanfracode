# Editor de video con Claude

Esta carpeta tiene las herramientas para editar video con Claude: Remotion (animaciones, subtítulos, exportar) y ffmpeg (cortar, audio, convertir). No hay interfaz ni plantillas: la persona te dice qué quiere y **tú, Claude, editas**. Habla siempre en **español, simple y corto**; la persona no programa.

- Primera vez en la carpeta, o algo no funciona → skill `instalar-editor`.
- Carpetas: `originales/` (videos crudos, nunca se tocan), `recursos/<VIDEO>/` (logos, capturas, grabaciones), `proyecto/mi-video/` (proyecto de Remotion; los videos nuevos son composiciones en `src/`), `entregas/` (MP4 finales).
- Copia a `proyecto/mi-video/public/` lo que uses en un video; no muevas los originales.

## Herramientas (en `proyecto/mi-video/scripts`)

- `transcribe.mts`: transcribe con Whisper, palabra por palabra.
- `limpiar-audio.mjs`: reduce ruido y deja la voz en -14 LUFS.
- `medir-voz.mjs`: volumen de la voz cada 20 ms, para cortar exacto en una palabra.
- `hoja-ojos.mjs`: hoja con la cara al inicio y final de cada toma, para ver si mira a cámara.
- `fotos.mjs`, `fotos-composicion.mjs`, `fotos-varias.mjs`: fotogramas de una composición, para revisarla sin exportar.
- `codec.mjs`: elige el codificador (tarjeta NVIDIA o procesador).

## Reglas de edición

- **Zonas seguras 1080×1920:** nada importante en los ~250 px de arriba, ~480 px de abajo ni ~150 px de la derecha; margen izquierdo ~60 px.
- **Subtítulos:** MAYÚSCULAS, Montserrat Black, blancos, sin recuadro, contorno negro grueso (~22 % del tamaño), palabra activa en un color de acento. Los títulos llevan el mismo contorno. Con subtítulo de una palabra, no taparle la boca (~64 px en cámara completa).
- **Alternar** pantalla completa y marco chico seguido; no quedarse mucho en el marco.
- **Audio:** reducción de ruido y -14 LUFS.
- **Siempre mirando a cámara:** terminar cada toma ~0.05–0.1 s después de la última palabra y revisar los ojos al inicio y final de cada toma (`hoja-ojos.mjs`).
- **No exportar MP4 hasta que la persona lo pida.** Primero se le muestra en la vista previa de Remotion (`npm run dev` dentro de `proyecto/mi-video`, puerto 3000) y con fotogramas. Exportar en 1080×1920.
- **Sin música propia:** cada video va sin música o con la que suba la persona.
- **Revisar antes de mostrar:** mira tú los fotogramas antes de decir que está listo.

## Exportar sin quemar la PC

`npx remotion render <Id> ../../entregas/<nombre>.mp4 --concurrency=2` (dentro de `proyecto/mi-video`). Cada `bundle()` de Remotion deja una carpeta `remotion-webpack-bundle-*` en la carpeta temporal del sistema: se puede borrar si el disco se llena.

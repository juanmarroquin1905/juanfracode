# Herramientas para editar video con Claude

1. **Descomprime** este zip donde quieras. Queda la carpeta `EDITOR-VIDEO`.
2. **Instala la app de Claude** (claude.ai/download) y, en la pestaña **Code**, abre la carpeta `EDITOR-VIDEO`.
3. Escríbele a Claude: **instala el editor**

Claude revisa tu PC, te pide permiso para instalar lo que falte (Node.js, ffmpeg y Remotion) y lo deja listo. Tarda unos minutos, una sola vez.

## Qué trae
- `.claude/skills/instalar-editor` — la skill que instala todo.
- `CLAUDE.md` — las reglas de edición.
- `proyecto/mi-video/` — proyecto de Remotion vacío y scripts de ayuda (transcribir, limpiar audio, fotogramas de revisión).
- `originales/`, `recursos/`, `entregas/` — tus videos crudos, tus logos y capturas, y tus MP4 finales.

Sin plantillas ni interfaz: Claude edita directamente con Remotion y ffmpeg. Funciona en Windows y Mac.
